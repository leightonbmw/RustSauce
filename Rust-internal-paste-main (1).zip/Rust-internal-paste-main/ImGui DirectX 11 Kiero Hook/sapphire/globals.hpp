#pragma once
#include "rust.hpp"

namespace sapphire {
	namespace globals {
		inline rust::classes::c_base_player* local;
	}
}