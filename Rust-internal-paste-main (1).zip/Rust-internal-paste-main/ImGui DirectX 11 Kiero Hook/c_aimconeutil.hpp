#pragma once
#include "rust/rust.hpp"

class rust::classes::c_aimconeutil 
{
public:



};