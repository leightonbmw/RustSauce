#include "hitmarkers.hpp"

auto sapphire::features::c_hitmarkers::run( ) -> void
{

}